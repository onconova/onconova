# Recurrence Of - Onconova Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Recurrence Of**

## Extension: Recurrence Of 

| | |
| :--- | :--- |
| *Official URL*:http://luisfabib.github.io/onconova/StructureDefinition/onconova-ext-recurrence-of | *Version*:0.1.0 |
| Active as of 2025-10-09 | *Computable Name*:RecurrenceOf |

Indicates that the condition is a recurrence of a previous condition, and provides a reference to that previous condition.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [Primary Cancer Condition Profile](StructureDefinition-onconova-primary-cancer-condition.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/onconova.fhir|current/StructureDefinition/onconova-ext-recurrence-of)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-onconova-ext-recurrence-of.csv), [Excel](StructureDefinition-onconova-ext-recurrence-of.xlsx), [Schematron](StructureDefinition-onconova-ext-recurrence-of.sch) 

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "onconova-ext-recurrence-of",
  "url" : "http://luisfabib.github.io/onconova/StructureDefinition/onconova-ext-recurrence-of",
  "version" : "0.1.0",
  "name" : "RecurrenceOf",
  "title" : "Recurrence Of",
  "status" : "active",
  "date" : "2025-10-09T11:30:09+00:00",
  "publisher" : "Onconova",
  "contact" : [
    {
      "name" : "Onconova",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://luisfabib.github.io/onconova"
        }
      ]
    }
  ],
  "description" : "Indicates that the condition is a recurrence of a previous condition, and provides a reference to that previous condition.",
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    }
  ],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [
    {
      "type" : "element",
      "expression" : "Element"
    }
  ],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension|4.0.1",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "Extension",
        "path" : "Extension",
        "short" : "Recurrence Of",
        "definition" : "Indicates that the condition is a recurrence of a previous condition, and provides a reference to that previous condition.",
        "constraint" : [
          {
            "key" : "recurrence-reference",
            "severity" : "error",
            "human" : "If the Condition.clinicalStatus extension is 'recurrence', the recurrenceOf extension must be present.",
            "expression" : "%resource.clinicalStatus.exists() and %resource.clinicalStatus = 'recurrence' implies exists() valueReference.exists()",
            "source" : "http://luisfabib.github.io/onconova/StructureDefinition/onconova-ext-recurrence-of|0.1.0"
          }
        ]
      },
      {
        "id" : "Extension.extension",
        "path" : "Extension.extension",
        "max" : "0"
      },
      {
        "id" : "Extension.url",
        "path" : "Extension.url",
        "fixedUri" : "http://luisfabib.github.io/onconova/StructureDefinition/onconova-ext-recurrence-of"
      },
      {
        "id" : "Extension.value[x]",
        "path" : "Extension.value[x]",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : [
              "http://hl7.org/fhir/us/mcode/StructureDefinition/mcode-primary-cancer-condition|4.0.0"
            ]
          }
        ]
      }
    ]
  }
}

```
