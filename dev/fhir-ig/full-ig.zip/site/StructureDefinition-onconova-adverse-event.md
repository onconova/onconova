# Adverse Event Profile - Onconova Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Adverse Event Profile**

## Resource Profile: Adverse Event Profile 

| | |
| :--- | :--- |
| *Official URL*:http://luisfabib.github.io/onconova/StructureDefinition/onconova-adverse-event | *Version*:0.1.0 |
| Active as of 2025-10-09 | *Computable Name*:OnconovaAdverseEvent |

 
A profile representing an adverse event experienced by a cancer patient as a result of an antineoplastic treatment, structured according to the Common Terminology Criteria for Adverse Events (CTCAE). This resource is used to capture and standardize the documentation of adverse events occurring during cancer care, including the type of event, its CTCAE grade, and any mitigation actions taken. 
The profile constrains the base FHIR`AdverseEvent`resource to ensure consistent use of CTCAE codes and grades, and supports linkage to related treatments such as medications, radiotherapy, or surgical procedures documented in Onconova. The profile also provides extensions for recording mitigation strategies, supporting detailed tracking and management of adverse events in cancer patients. 

**Usages:**

* This Profile is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/onconova.fhir|current/StructureDefinition/onconova-adverse-event)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-onconova-adverse-event.csv), [Excel](StructureDefinition-onconova-adverse-event.xlsx), [Schematron](StructureDefinition-onconova-adverse-event.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "onconova-adverse-event",
  "url" : "http://luisfabib.github.io/onconova/StructureDefinition/onconova-adverse-event",
  "version" : "0.1.0",
  "name" : "OnconovaAdverseEvent",
  "title" : "Adverse Event Profile",
  "status" : "active",
  "date" : "2025-10-09T11:39:09+00:00",
  "publisher" : "Onconova",
  "contact" : [
    {
      "name" : "Onconova",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://luisfabib.github.io/onconova"
        }
      ]
    }
  ],
  "description" : "A profile representing an adverse event experienced by a cancer patient as a result of an antineoplastic treatment, structured according to the Common Terminology Criteria for Adverse Events (CTCAE). This resource is used to capture and standardize the documentation of adverse events occurring during cancer care, including the type of event, its CTCAE grade, and any mitigation actions taken.\n\nThe profile constrains the base FHIR `AdverseEvent` resource to ensure consistent use of CTCAE codes and grades, and supports linkage to related treatments such as medications, radiotherapy, or surgical procedures documented in Onconova. The profile also provides extensions for recording mitigation strategies, supporting detailed tracking and management of adverse events in cancer patients.",
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "w5",
      "uri" : "http://hl7.org/fhir/fivews",
      "name" : "FiveWs Pattern Mapping"
    },
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    }
  ],
  "kind" : "resource",
  "abstract" : false,
  "type" : "AdverseEvent",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/AdverseEvent|4.0.1",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "AdverseEvent",
        "path" : "AdverseEvent"
      },
      {
        "id" : "AdverseEvent.extension",
        "path" : "AdverseEvent.extension",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "value",
              "path" : "url"
            }
          ],
          "ordered" : false,
          "rules" : "open"
        },
        "min" : 1
      },
      {
        "id" : "AdverseEvent.extension:ctcGrade",
        "path" : "AdverseEvent.extension",
        "sliceName" : "ctcGrade",
        "short" : "CTCAE Grade",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Extension",
            "profile" : [
              "http://luisfabib.github.io/onconova/StructureDefinition/onconova-ext-ctc-grade|0.1.0"
            ]
          }
        ]
      },
      {
        "id" : "AdverseEvent.extension:adverseEventMitigation",
        "path" : "AdverseEvent.extension",
        "sliceName" : "adverseEventMitigation",
        "short" : "Adverse Event Mitigation Action(s)",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Extension",
            "profile" : [
              "http://luisfabib.github.io/onconova/StructureDefinition/onconova-ext-adverse-event-mitigation|0.1.0"
            ]
          }
        ]
      },
      {
        "id" : "AdverseEvent.actuality",
        "path" : "AdverseEvent.actuality",
        "patternCode" : "actual"
      },
      {
        "id" : "AdverseEvent.category",
        "path" : "AdverseEvent.category",
        "short" : "Not used in this profile",
        "definition" : "Not used in this profile"
      },
      {
        "id" : "AdverseEvent.event",
        "path" : "AdverseEvent.event",
        "binding" : {
          "strength" : "required",
          "valueSet" : "http://luisfabib.github.io/onconova/ValueSet/onconova-vs-ctc-adverse-events|0.1.0"
        }
      },
      {
        "id" : "AdverseEvent.subject",
        "path" : "AdverseEvent.subject",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : [
              "http://luisfabib.github.io/onconova/StructureDefinition/onconova-cancer-patient|0.1.0"
            ]
          }
        ]
      },
      {
        "id" : "AdverseEvent.encounter",
        "path" : "AdverseEvent.encounter",
        "short" : "Not used in this profile",
        "definition" : "Not used in this profile"
      },
      {
        "id" : "AdverseEvent.detected",
        "path" : "AdverseEvent.detected",
        "short" : "Not used in this profile",
        "definition" : "Not used in this profile"
      },
      {
        "id" : "AdverseEvent.recordedDate",
        "path" : "AdverseEvent.recordedDate",
        "short" : "Not used in this profile",
        "definition" : "Not used in this profile"
      },
      {
        "id" : "AdverseEvent.resultingCondition",
        "path" : "AdverseEvent.resultingCondition",
        "short" : "Not used in this profile",
        "definition" : "Not used in this profile"
      },
      {
        "id" : "AdverseEvent.location",
        "path" : "AdverseEvent.location",
        "short" : "Not used in this profile",
        "definition" : "Not used in this profile"
      },
      {
        "id" : "AdverseEvent.seriousness",
        "path" : "AdverseEvent.seriousness",
        "short" : "Not used in this profile",
        "definition" : "Not used in this profile"
      },
      {
        "id" : "AdverseEvent.severity",
        "path" : "AdverseEvent.severity",
        "short" : "Not used in this profile",
        "definition" : "Not used in this profile"
      },
      {
        "id" : "AdverseEvent.recorder",
        "path" : "AdverseEvent.recorder",
        "short" : "Not used in this profile",
        "definition" : "Not used in this profile"
      },
      {
        "id" : "AdverseEvent.contributor",
        "path" : "AdverseEvent.contributor",
        "short" : "Not used in this profile",
        "definition" : "Not used in this profile"
      },
      {
        "id" : "AdverseEvent.suspectEntity.instance",
        "path" : "AdverseEvent.suspectEntity.instance",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : [
              "http://luisfabib.github.io/onconova/StructureDefinition/onconova-medication-administration|0.1.0",
              "http://luisfabib.github.io/onconova/StructureDefinition/onconova-radiotherapy-summary|0.1.0",
              "http://luisfabib.github.io/onconova/StructureDefinition/onconova-surgical-procedure|0.1.0"
            ]
          }
        ]
      }
    ]
  }
}

```
